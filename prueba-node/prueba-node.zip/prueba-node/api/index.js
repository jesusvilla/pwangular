const express = require('express');

var apiRouter = express.Router();
apiRouter.route('/').get((req, res, next)=>{
  res.json({version: '1.0.0'})
})

apiRouter.route('/test').get((req, res, next) => {
  res.json({uno: 'Uno, dos, tres, cuatro, cinco, seis, siete, ocho, nueve, diez'})
})

module.exports = apiRouter